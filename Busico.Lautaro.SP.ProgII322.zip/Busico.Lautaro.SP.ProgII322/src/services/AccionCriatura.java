
package services;

import model.Criatura;

@FunctionalInterface
public interface AccionCriatura {
    abstract void ejecutar(Criatura ciatura);
}
