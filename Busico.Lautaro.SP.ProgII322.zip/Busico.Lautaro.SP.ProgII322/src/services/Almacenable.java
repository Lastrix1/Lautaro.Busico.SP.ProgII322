
package services;


public interface Almacenable<T> extends Iterable<T> {
     void agregar(T item);
    
    
    boolean eliminar(T item);
    
    
    boolean contiene(T item);
    
    
    T obtener(int indice);
    
    
    int tam();
    
    
    default boolean estaVacio(){
        return tam()==0;
    }
    
     
    default void mostrarContenido(){
        if (estaVacio()){
            System.out.println("lista vacia");
        }
        else{
            System.out.println("contenido de almacen");
            for(T item : this){
                System.out.println(item);
            }
        }
    }
}
