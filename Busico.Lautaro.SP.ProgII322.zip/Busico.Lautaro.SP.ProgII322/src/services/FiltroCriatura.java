
package services;

import model.Criatura;

@FunctionalInterface
public interface FiltroCriatura {
   abstract boolean filtrar(Criatura criatura);
}
