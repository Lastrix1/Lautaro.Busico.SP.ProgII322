/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author busic
 */
public interface RutaBestiario {
       static final String BASE ="src/resources/"; 
   static final String FILE_CSV= "Criatura.csv";
   static final String FILE_BIN= "Criatura.bin";
   
   static Path getRutaCSV(){
       return Paths.get(BASE,FILE_CSV);
   }
   
   static Path getRutaBin(){
       return Paths.get(BASE,FILE_BIN);
   }
   
   static String getRutaBinString(){
       return getRutaBin().toString();
   }
   
   static String getRutaCSVString(){
       return getRutaCSV().toString();
   }
   
}
