/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package model;

/**
 *
 * @author busic
 */
public enum Tipo {
    DEMOGORGON,
    DEMODOG,
    SHADOW_MONSTER,
    MIND_FLAYER_MINION,
    MURCIELAGO,
    OTRO
}
