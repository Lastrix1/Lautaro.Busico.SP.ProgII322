package model;

import java.util.List;
import percistencia.CSVSerializable;


public class Criatura implements Comparable<Criatura>, CSVSerializable {

    public String getNombre() {
        return nombre;
    }

    public int getId() {
        return id;
    }

    public String getOrigen() {
        return origen;
    }

    public Tipo getTipo() {
        return tipo;
    }

    private final String nombre;
    private final int id;
    private final String origen;
    private final Tipo tipo;

    public Criatura(int id, String nombre, String origen, Tipo tipo) {
        this.nombre = nombre;
        this.id = id;
        this.origen = origen;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Criatura{" + "nombre=" + nombre + ", id=" + id + ", origen=" + origen + ", tipo=" + tipo + '}';
    }

    @Override
    public int compareTo(Criatura o) {
        return Integer.compare(id, o.id);
    }

    @Override
    public String toCSV() {
        return id + ";" + nombre + ";" + origen + ";" + tipo + "\n";
    }



}
