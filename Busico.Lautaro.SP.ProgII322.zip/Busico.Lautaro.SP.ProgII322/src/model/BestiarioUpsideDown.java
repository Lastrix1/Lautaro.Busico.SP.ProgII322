package model;

import config.RutaBestiario;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import percistencia.CSVSerializable;
import services.AccionCriatura;
import services.Almacenable;
import services.FiltroCriatura;

public class BestiarioUpsideDown<T> implements Almacenable<T> {

    private final List<T> bestiario;
    private static File criaturaCSV = new File(RutaBestiario.getRutaCSVString());
    private static File criaturasBin = new File(RutaBestiario.getRutaBinString());

    public BestiarioUpsideDown() {
        this.bestiario = new ArrayList<>();
    }

    @Override
    public void agregar(T item) {
        bestiario.add(item);
    }

    @Override
    public boolean eliminar(T item) {
        return bestiario.remove(item);
    }

    @Override
    public boolean contiene(T item) {
        return bestiario.contains(item);
    }

    @Override
    public T obtener(int indice) {
        return bestiario.get(indice);
    }

    @Override
    public int tam() {
        return bestiario.size();
    }

    @Override
    public Iterator<T> iterator() {
        if (bestiario.isEmpty() || !(bestiario.get(0) instanceof Comparable)) {
            return copiarLista().iterator();
        }

        return iterator((Comparator<T>) Comparator.naturalOrder());

    }

    public Iterator<T> iterator(Comparator<? super T> cmp) {
        return copiaOrdenada(cmp).iterator();
    }

    private List<T> copiarLista() {
        return new ArrayList<>(bestiario);
    }

    public List<T> copiaOrdenada(Comparator<? super T> cmp) {
        List<T> copia = copiarLista();
        copia.sort(cmp);
        return copia;
    }


    public static List<Criatura> filtrar(List<Criatura> criaturas, FiltroCriatura filtro) {
        List<Criatura> toReturn = new ArrayList<>();
        for (Criatura criatura : criaturas) {
            if (filtro.filtrar(criatura)) {
                toReturn.add(criatura);
            }
        }

        return toReturn;
    }

    public static void ordenarCriaturas(List<Criatura> criaturas, Comparator<Criatura> criterio) {
        criaturas.sort(criterio);
    }

    public void mostarContenidoNatuarl() {
        mostar(this);
    }

    private void mostar(Iterable<T> it) {
        for (T el : it) {
            System.out.println(el);
        }
    }
    public void mostrarContenido(Comparator<? super T> cmp){
        List<T> copia=copiarLista();
        copia.sort(cmp);
        mostar(copia);
       
    }
       
    
    
    
    
}
