
package model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import services.AccionCriatura;
import services.FiltroCriatura;


public class FiltradoCriatura {
        public static BestiarioUpsideDown<Criatura> filtrarCriaturas(BestiarioUpsideDown<Criatura> criaturas, FiltroCriatura filtro){
      BestiarioUpsideDown<Criatura> toReturn = new BestiarioUpsideDown<>();
      for(Criatura criatura:criaturas){
          if(filtro.filtrar(criatura)){
              toReturn.agregar(criatura);
          }
      }
      
      
      return toReturn;
    }
    public static void ordenarCriaturas(List<Criatura> criaturas, Comparator<Criatura> criterio){
        criaturas.sort(criterio);
    }

}
