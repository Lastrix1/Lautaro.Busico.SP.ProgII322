package lautaro.busico.pkg2p.pkg322;

import model.Criatura;
import model.BestiarioUpsideDown;
import model.Tipo;
import java.io.IOException;
import java.util.List;
import model.FiltradoCriatura;
import model.Tipo;
import percistencia.PersitenciaCriatura;

public class LautaroBusico2p322 {

   

        public static void main(String[] args) {
            BestiarioUpsideDown<Criatura> bestiario = new BestiarioUpsideDown<>();
            bestiario.agregar(new Criatura(1, "Demogorgon", "Upside Down",
                    Tipo.DEMOGORGON));
            bestiario.agregar(new Criatura(2, "Demodog Juvenil", "Bosque de Hawkins",
                    Tipo.DEMODOG));
            bestiario.agregar(new Criatura(3, "Shadow Tendril", "Dimensión Principal",
                    Tipo.SHADOW_MONSTER));
            bestiario.agregar(new Criatura(4, "Mind Flayer Spawn", "Upside Down",
                    Tipo.MIND_FLAYER_MINION));
            bestiario.agregar(new Criatura(5, "Murciélago del Upside Down", "Cueva Oscura",
                    Tipo.MURCIELAGO));
            System.out.println("Criaturas:");
            bestiario.mostarContenidoNatuarl();
            System.out.println("\nCriaturas tipo DEMODOG:");
            BestiarioUpsideDown<Criatura> demodog =FiltradoCriatura.filtrarCriaturas(bestiario, (p1) -> p1.getTipo().equals(Tipo.DEMODOG));
            demodog.mostarContenidoNatuarl();
            System.out.println("\nCriaturas que contienen 'shadow':");
            BestiarioUpsideDown<Criatura> shadow =FiltradoCriatura.filtrarCriaturas(bestiario, (p1) -> p1.getTipo().equals(Tipo.SHADOW_MONSTER));
            shadow.mostarContenidoNatuarl();
            System.out.println("\nCriaturas ordenadas por ID:");
            bestiario.mostarContenidoNatuarl();
            System.out.println("\nCriaturas ordenadas por nombre:");
            bestiario.mostrarContenido((p1,p2)->p1.getNombre().compareTo(p2.getNombre())/* Lambda */);
            PersitenciaCriatura.serializarBestia(bestiario,"src/resources/criaturas.dat");
            BestiarioUpsideDown<Criatura> cargado = PersitenciaCriatura.deserializarBestia("src/resources/criaturas.dat");
            System.out.println("\nCriaturas cargadas desde archivo binario:");
            PersitenciaCriatura.guardarBestiaCSV(bestiario,"src/resources/criaturas.csv");
            cargado=PersitenciaCriatura.cargarBestiaCSV("src/resources/criaturas.csv");
            System.out.println("\nCriaturas cargadas desde archivo CSV:");
        }
    }

