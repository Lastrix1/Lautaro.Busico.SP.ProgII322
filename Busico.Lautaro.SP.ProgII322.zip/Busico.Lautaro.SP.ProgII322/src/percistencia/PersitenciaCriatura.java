package percistencia;

import config.RutaBestiario;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import model.BestiarioUpsideDown;
import model.Criatura;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author busic
 */
public class PersitenciaCriatura {

    
   
    public static void guardarBestiaCSV(BestiarioUpsideDown<? extends Criatura> lista,String Path){
        try(BufferedWriter buffer = new BufferedWriter(new FileWriter(Path))){
            for(Criatura criatura:lista){
                buffer.write(criatura.toCSV());
            }
        
        }catch (IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public static BestiarioUpsideDown<Criatura> cargarBestiaCSV(String path){
        try(BufferedReader buffer= new BufferedReader(new FileReader(path))){
            String linea;
            BestiarioUpsideDown<Criatura> criaturas = new BestiarioUpsideDown<>();
            while ((linea = buffer.readLine()) != null){
                criaturas.agregar(CSVSerializable.fromCSV(linea));
            }
            return criaturas;
        }
        catch (IOException ex){
            System.out.println(ex.getMessage());
        }
        
        return null;
    }
    public static void serializarBestia(BestiarioUpsideDown<? extends Criatura> lista, String path){
        try(ObjectOutputStream archivo = new ObjectOutputStream(new FileOutputStream(path))){
            archivo.writeObject(lista);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
      
    }
    public static BestiarioUpsideDown<Criatura> deserializarBestia(String path){
         BestiarioUpsideDown<Criatura> empleados=new BestiarioUpsideDown<>();
        try(ObjectInputStream archivo = new ObjectInputStream(new FileInputStream(path))){
           empleados= (BestiarioUpsideDown<Criatura>)archivo.readObject();
            
        }catch(IOException |ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }
        return empleados;
    }

}
