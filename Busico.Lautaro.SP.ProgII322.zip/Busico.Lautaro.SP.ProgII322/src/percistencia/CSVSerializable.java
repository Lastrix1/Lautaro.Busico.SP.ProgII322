
package percistencia;

import model.Criatura;
import model.Tipo;


public interface CSVSerializable {
    String toCSV();
    
     
     
    static Criatura fromCSV(String linea){
        linea.replace("\n", "");
        String[] pates = linea.split(";");
        return new Criatura(Integer.parseInt(pates[0]),pates[1],pates[2],Tipo.valueOf(pates[3]));
    }
    
}
